Noor Shah and Nuzhat Tanjil
https://github.com/noorshah4/Project-3.git

In this Client-Server application all the required commands are implemented which are given in the pdf file(project file). To run this project, first of you need to run server.py file in python installed enviroment.
Then you can run client.py file multiple times in different windows(powershell, linux terminal). Each window is a client connected to server(if logedin).

Run your server.py file:
	pyhton server.py
Run your client.py file:
	python client.py

Commands:
For Login Information:
	LOGIN root root22 (login as root)
	LOGIN john john22 (login as normal user)
if the command is not in correct format or credentials are not correct server will send invalid command response.


After login with correct credentials(as normal user):
	1: You can find circumference and area of circle by using following command:
		SOLVE -c 4

	2: You can find perimeter and area of rectangle by using following command:
		SOLVE -r 4 5
			or
		SOLVE -r 4  (here 4 will be considered for length and width)	

	3: You can see your solutions that you have solved earlier by using following command:
		LIST (it will show you all the solutions that you have requested earlier)

	3: You can logout from the server by using following command:
		LOGOUT

	4: You can shutdown the server from clientside by using following command
		SHUTDOWN

	5: You can send message to other client who is connected to the server by using following command:
		MESSAGE john HELLO I'M JOHN, HOW ARE YOU?
		(In this format john is reciever's username, after that you write your message)



After login with correct credentials(as root user):
	1: You can find circumference and area of circle by using following command:
		SOLVE -c 4

	2: You can find perimeter and area of rectangle by using following command:
		SOLVE -r 4 5
			or
		SOLVE -r 4  (here 4 will be considered for length and width)	

	3: You can see your solutions that you have solved earlier by using following command:
		LIST (it will show you all the solutions that you have requested earlier)

	4: You can see all the solutions of every client that are solved by the users by using following command:
		LIST -all

	3: You can logout from the server by using following command:
		LOGOUT

	4: You can shutdown the server from clientside by using following command
		SHUTDOWN

	5: You can send message to other client who is connected to the server by using following command:
		MESSAGE john HELLO I'M ROOT, HOW ARE YOU?
		(In this format john is reciever's username, after that you write your message)

	6: You can send message to all the clients who are connected to the server by using following command:
		MESSAGE -all HELLO I'M ROOT, HOW ARE YOU ALL?
		(In this format '-all' indicate you are sending this message to everyone, after that you write your message)

# Password based authentication
Client-Server program which will facilitate a client to register itself to the server. A server should keep a table of user-hash(password) entry for each user.

This program registers user with username, password and stores password hash in dictonary. Also, when a user tries to login , password validation occurs.

Python,Socket programming 

## IMPLEMENTATION (python3)
SERVER : socket with multithreading
CLIENT : socket
HASH : SHA256 ( using pythons hashlib)

```
INPUT (client side)
1. Username
2. Password
```
```
OUPUT
1. Registeration Successful : new user
2. Connection Successful : password correct
3. Login Failed : password incorrect 

Hash table : Contains User and Password. It is implemented using python Dictionary data structure
```