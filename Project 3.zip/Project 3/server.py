import socket
import math
import threading
import glob
import os
import time


Clients=[]
Names=[]


# Create Socket (TCP) Connection
ServerSocket = socket.socket(family = socket.AF_INET, type = socket.SOCK_STREAM) 
host = '127.0.0.1'
port = 1233
ThreadCount = 0
try:
    ServerSocket.bind((host, port))
except socket.error as e:
    print(str(e))

print('Waitiing for a Connection..')
ServerSocket.listen(5)


#this funtion authenticate user from database
def authencateUser(uname,passcode):
    f = open("LOGINS.txt", "r")
    for x in f:
        com1 = x.split(',')[0]
        com2 = x.split(',')[1]
        cm = com2.replace('\n','')
        if com1 == uname and cm == passcode:
            return True
    else:
        return False

# Function to convert
def listToString(s):
	
	# initialize an empty string
	str1 = ","
	
	# return string
	return (str1.join(s))

#function to decode() and append values to list
def getvalues(l):
    ls=[]
    for m in l:
        ls.append(m.decode())

    return ls


#function to find circumference and area of circle
def findcircumference(radius):
    r=int(radius)
    circumference = 2 * math.pi * r
    area = math.pi * r * r
    return circumference, area

#function to find perimeter and area of rectangle
def findRecPA(l,w):
    A=int(l)*int(w)
    P=2*(int(l)+int(w))
    return P,A

#function to maintain userlogs(store solutions)
def maintainUserlog(fname,str='',data=''):
    filename = fname
    text_file = open(filename+'.txt', "a")
    text_file.write(str)
    text_file.write(data)
    text_file.write('\n')
    text_file.close()


#funtion to get user logs from text file
def getuserlog(name):
    filename= name
    str=''
    f = open(filename+'.txt', "r")
    for i in f:
        str+=i
    return str

#function to get data from all user files except login file.
def getallfiledata():
    my_files = glob.glob('*.txt')
    str=''
    for i in my_files:
        if i!="LOGINS.txt":
            f = open(i, "r")
            for x in f:
                str+=x
    return str

#funtion to close connection
def close():
    os._exit(0)

#funtion to check if user exist in file or not
def checkuserinfile(name):
    f = open(name+".txt", "a")
    f = open(name+".txt", "r")
    for i in f:
        if name==i.replace('\n',''):
            return True
        else:
            return False
#internal function to if certain user exist in list or not and return index of user
def checku(name):
    try:
        index = Names.index(name)
        return index
    except:
        return 'f'

#function to get message from user input
def getmessage(l):
    str=''
    for s in l[2:]:
        str += s
        str+=" "
    return str


# Function : For each client 
def threaded_client(connection):
    connection.send(str.encode('ENTER Login Information: ')) # Request Username
    #getting login information in variables
    login, name, password = connection.recv(2048).split()
    passcode = password.decode()
    uname = name.decode()
    #authencating user
    if(authencateUser(uname,passcode))==False:
        connection.send(str.encode('Invalid Credentials! Connect again\n'))
    elif (authencateUser(uname,passcode))==True:
        #checking username already exist
        if checkuserinfile(uname)==True:
            maintainUserlog(uname)
        else:
            #saving logs of user
            maintainUserlog(uname,uname)
    if login.decode()=="LOGIN":
        if(authencateUser(uname,passcode)):
            Names.append(uname)
            #checking if user is not root 
            if uname != "root" and passcode != "root22":
                connection.send(str.encode('Login Successfull!\nEnter your command or enter M to see mesaage\n'))
                data = connection.recv(2048).split()
                d = getvalues(data)
                if d[0]=="M":
                    connection.send(str.encode('\n'))
                elif len(data)==3:
                    data = getvalues(data)
                    if data[0]=="SOLVE":
                        if data[1]=="-c":
                            #getting circumference and area                       
                            circumference, area=findcircumference(data[2])
                            #sending response to user
                            connection.send(str.encode('Circle Circumference is '))
                            connection.send(str(circumference).encode('utf8'))
                            connection.send(str.encode('and area is '))
                            connection.send(str(area).encode('utf8'))
                            #maintaing logs of solutions
                            maintainUserlog(uname,'Radius: ',str(data[2]))
                            maintainUserlog(uname,'Cicle circumference is ', str(circumference))
                            maintainUserlog(uname,'and area is ',str(area))

                        elif data[1]=='-r':
                            v2=data[2]
                            p,a=findRecPA(data[2],v2)
                            connection.send(str.encode('Rectangle peremeter is '))
                            connection.send(str(p).encode('utf8'))
                            connection.send(str.encode(' and area is '))
                            connection.send(str(a).encode('utf8'))
                            maintainUserlog(uname,'Sides: ',str(data[2]))
                            maintainUserlog(uname,'Rectangle perimeter is ', str(p))
                            maintainUserlog(uname,'and area is ',str(a))
                        else:
                            connection.send(str.encode('Invalid Command'))
                    elif data[0]=="MESSAGE":
                        rec = data[1]
                        msg = data[2]
                        c = checku(rec)
                        if c!='f':
                            index = Clients[c]
                            msg1 = "Message From: "+ uname +"\n"
                            index.send(msg1.encode('utf-8'))
                            index.send(msg.encode('utf-8'))
                            print(msg1,"\n")
                            print(msg,"\n")
                        else:
                            connection.send(str.encode('User does not exit'))
                    else:
                        connection.send(str.encode('Invalid Command'))

                        
                elif len(data)==4:
                    data = getvalues(data)
                    if data[0]=="SOLVE":
                        if data[1]=="-r":           
                            p,a=findRecPA(data[2],data[3])
                            connection.send(str.encode('Rectangle peremeter is '))
                            connection.send(str(p).encode('utf8'))
                            connection.send(str.encode(' and area is '))
                            connection.send(str(a).encode('utf8'))
                            maintainUserlog(uname,'Sides: ',str(data[2]))
                            maintainUserlog(uname,'Rectangle perimeter is ', str(p))
                            maintainUserlog(uname,'and area is ',str(a))
                        else:
                            connection.send(str.encode('Invalid Command'))
                    elif data[0]=="MESSAGE":
                        rec = data[1]
                        msg = getmessage(data)
                        c = checku(rec)
                        if c!= 'f':
                            index = Clients[c]
                            msg1 = "Message From: "+ uname +"\n"
                            index.send(msg1.encode('utf-8'))
                            index.send(msg.encode('utf-8'))
                            print(msg1,"\n")
                            print(msg,"\n")
                        else:
                            connection.send(str.encode('User does not exit'))
                    else:
                        connection.send(str.encode('Invalid Command'))
                
                elif len(data)==1:
                    data = getvalues(data)
                    if data[0]=="LIST":
                        user_log = getuserlog(uname)
                        connection.send(str(user_log).encode('utf8'))
                    elif data[0] == "SHUTDOWN":
                        connection.sendall(str.encode('200 OK'))
                        time.sleep(2)
                        connection.close()
                        close()
                    elif data[0]=="LOGOUT":
                        connection.sendall(str.encode('200 OK'))
                        time.sleep(2)
                        connection.close()
                    else:
                        connection.send(str.encode('Invalid Command'))
                elif len(data)>4:
                    data = getvalues(data)
                    if data[0]=="MESSAGE":
                        rec = data[1]
                        msg = getmessage(data) 
                        c = checku(rec)
                        if c!='f':
                            index = Clients[c]
                            msg1 = "Message From: "+ uname +"\n"
                            index.send(msg1.encode('utf-8'))
                            index.send(msg.encode('utf-8'))
                            print(msg1,"\n")
                            print(msg,"\n")
                        else:
                            connection.send(str.encode('User does not exist'))
                else:
                    connection.send(str.encode('Not enough argument for command'))

            else:
                #if user is login as root
                connection.send(str.encode('Root Login Successfull!\nEnter your command or press M to see Message:\n'))
                data = (connection.recv(2048).split())
                d = getvalues(data)
                if d[0]=="M":
                    connection.send(str.encode(''))
                if len(data)==3:
                    data = getvalues(data)
                    if data[0]=="SOLVE":
                        if data[1]=="-c":                
                            circumference, area=findcircumference(data[2])
                            connection.send(str.encode('Circle Circumference is '))
                            connection.send(str(circumference).encode('utf8'))
                            connection.send(str.encode('and area is '))
                            connection.send(str(area).encode('utf8'))
                            maintainUserlog(uname,'Radius: ',str(data[2]))
                            maintainUserlog(uname,'Cicle circumference is ', str(circumference))
                            maintainUserlog(uname,'and area is ',str(area))

                        elif data[1]=='-r':
                            v2=data[2]
                            p,a=findRecPA(data[2],v2)
                            connection.send(str.encode('Rectangle peremeter is '))
                            connection.send(str(p).encode('utf8'))
                            connection.send(str.encode(' and area is '))
                            connection.send(str(a).encode('utf8'))
                            maintainUserlog(uname,'Sides: ',str(data[2]))
                            maintainUserlog(uname,'Rectangle perimeter is ', str(p))
                            maintainUserlog(uname,'and area is ',str(a))
                        else:
                            connection.send(str.encode('Invalid Command'))
                    elif data[0]=="MESSAGE":
                        if data[1]!="-all":
                            rec = data[1]
                            msg = getmessage(data) 
                            c = checku(rec)
                            if c!='f':
                                index = Clients[c]
                                msg1 = "Message From: "+ uname +"\n"
                                index.send(msg1.encode('utf-8'))
                                index.send(msg.encode('utf-8'))
                                print(msg1,"\n")
                                print(msg,"\n")
                            else:
                                connection.send(str.encode('User does not exist'))

                    else:
                        connection.send(str.encode('Invalid Command'))

                        
                elif len(data)==4:
                    data = getvalues(data)
                    if data[0]=="SOLVE":
                        if data[1]=="-r":           
                            p,a=findRecPA(data[2],data[3])
                            connection.send(str.encode('Rectangle peremeter is '))
                            connection.send(str(p).encode('utf8'))
                            connection.send(str.encode(' and area is '))
                            connection.send(str(a).encode('utf8'))
                            maintainUserlog(uname,'Sides: ',str(data[2]))
                            maintainUserlog(uname,'Rectangle perimeter is ', str(p))
                            maintainUserlog(uname,'and area is ',str(a))
                        else:
                            connection.send(str.encode('Invalid Command'))
                    elif data[0]=="MESSAGE":
                        if data[1]!="-all":
                            rec = data[1]
                            msg = getmessage(data) 
                            c = checku(rec)
                            if c!='f':
                                index = Clients[c]
                                msg1 = "Message From: "+ uname +"\n"
                                index.send(msg1.encode('utf-8'))
                                index.send(msg.encode('utf-8'))
                                print(msg1,"\n")
                                print(msg,"\n")
                            else:
                                connection.send(str.encode('User does not exist'))
                        elif data[1]=="-all":
                            # rec = data[1]
                            msg = getmessage(data) 
                            # c = checku(rec)
                            for i in Clients:
                                msg1 = "Message From: "+ uname +"\n"
                                i.send(msg1.encode('utf-8'))
                                i.send(msg.encode('utf-8'))
                                print(msg1,"\n")
                                print(msg,"\n")
                        else:
                            connection.send(str.encode('Invalid Command'))
                    else:
                        connection.send(str.encode('Invalid Command'))
                elif len(data)==2:
                    data = getvalues(data)
                    if data[0]=="LIST" and data[1]=="-all":
                        rd = getallfiledata()
                        connection.send(str(rd).encode('utf8'))
                elif len(data)==1:
                    data = getvalues(data)
                    if data[0]=="SHUTDOWN":
                        connection.sendall(str.encode('200 OK'))
                        time.sleep(2)
                        connection.close()
                        close()
                    elif data[0]=="LOGOUT":
                        connection.sendall(str.encode('200 OK'))
                        time.sleep(2)
                        connection.close()
                    elif data[0] ==  "LIST":
                        user_log = getuserlog(uname)
                        connection.send(str(user_log).encode('utf8'))
                elif len(data)>4:
                    data = getvalues(data)
                    if data[0]=="MESSAGE" and data[1]!="-all":
                        rec = data[1]
                        msg = getmessage(data) 
                        c = checku(rec)
                        if c!='f':
                            index = Clients[c]
                            msg1 = "Message From: "+ uname +"\n"
                            index.send(msg1.encode('utf-8'))
                            index.send(msg.encode('utf-8'))
                            print(msg1,"\n")
                            print(msg,"\n")
                        else:
                            connection.send(str.encode('User does not exist'))
                    elif data[0]=="MESSAGE" and data[1]=="-all":
                            msg = getmessage(data) 
                            c = checku("root")
                            for i in Clients:
                                if i!=Clients[c]:
                                    msg1 = "Message From: "+ uname +"\n"
                                    i.send(msg1.encode('utf-8'))
                                    i.send(msg.encode('utf-8'))
                            print(msg1,"\n")
                            print(msg,"\n")
                    
                    else:
                        connection.send(str.encode('Invalid Command'))
                else:
                    connection.send(str.encode('Not enough argument for command'))


        else:
            connection.send(str.encode('Login Failed')) # Response code for login failed
            print('Connection denied : ',name.decode())
    else:
        connection.send(str.encode('Command or Format incorrect')) # Response code for incorrect login format



    while True:
        break


    connection.close()

while True:
    #Threads for multiple users
    Client, address = ServerSocket.accept()
    client_handler = threading.Thread(
        target=threaded_client,
        args=(Client,)  
    )
    Clients.append(Client)
    client_handler.start()
    ThreadCount += 1
    print('Connection Request: ' + str(ThreadCount))
    